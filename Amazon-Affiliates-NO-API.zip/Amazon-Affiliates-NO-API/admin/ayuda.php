<?php

?>

<div class="wrap">
	<div class="logo-container">
    <a href="https://digitablesolutions.com">
        <img src="<?php echo NAAA_URL_IMG; ?>logo-plugins.png" alt="Plugin Creado Por FJ" style="width: 720px; height: 244px;">
    </a>
</div>
    <h1 class="wp-heading-inline"><?php echo get_admin_page_title() ?></h1>
    <p><?php _e('En está sección encontrará ayuda útil sobre cómo utilizar Amazon Affiliate Pro', 'no-api-amazon-affiliate') ?></p>

	<h2 class="wp-heading-inline"><?php _e('Donde obtener el código ASIN', 'no-api-amazon-affiliate') ?></h2>
    <p>
        <?php _e('<strong>El código ASIN</strong> identifica a un producto en Amazon. Para obtener el código ASIN navegue hasta el producto deseado en la página de amazon.', 'no-api-amazon-affiliate') ?><br>
        <?php _e('En la url del navegador, podrá visualizar el ASIN después del identificador /dp/.', 'no-api-amazon-affiliate') ?><br>
        <?php _e('Es un código formado por 10 caracteres en mayúsculas.', 'no-api-amazon-affiliate') ?>
    </p>
    <div>
        <img style="border: #e0e0e0; border-style: inset; border-width: 3px;"src="<?php echo NAAA_URL_IMG; ?>/amazon_url_asin.jpg" alt="Amazon Asin Url" class="sp-rounded">
        <figcaption class="sp-text-neutral-80 sp-text-15px sp-text-center sp-mt-6">Ejemplo: Como Obtener ASIN de la url de amazon</figcaption>
    </div>
	
    <h2 class="wp-heading-inline"><?php _e('Uso básico', 'no-api-amazon-affiliate') ?></h2>
    <p><?php _e('Usar el plugin es muy fácil y sencillo. Simplemente utilice un <strong>Shortcode</strong> con la etiqueta <strong>amazon</strong>.', 'no-api-amazon-affiliate') ?></p>
    <p><?php _e('A continuación, use la propiedad <strong>asin</strong> para indicar el producto de amazon que desea mostrar.', 'no-api-amazon-affiliate') ?></p>
    <p><?php _e('Por ejemplo, si quiere mostrar el producto de amazon con el asin B08B99D7FJ, debería usar el shortcode siguiente:', 'no-api-amazon-affiliate') ?></p>
    <code >[amazon asin="B004RG9WAC"] o tambien [amazon bestseller="afeitadoras para hombres" max=4] </code>
    <br><br>
    <div>
        <img style="border: #e0e0e0; border-style: inset; border-width: 3px;"src="<?php echo NAAA_URL_IMG; ?>producto1.png" alt="Amazon Asin Url" class="sp-rounded">
    </div>
	
	<h2 class="wp-heading-inline"><?php _e('BOTON CALL TO CLICK', 'no-api-amazon-affiliate') ?></h2>
    <p><?php _e('Usar un boton de llamada a la accion despues de un cuadro de ventajas y desventajas. Simplemente utilice un <strong>Shortcode</strong> con la etiqueta <strong>amazon</strong>.', 'no-api-amazon-affiliate') ?></p>
    <p><?php _e('A continuación, use la propiedad <strong>asin</strong> para indicar el producto de amazon que desea mostrar en boton.', 'no-api-amazon-affiliate') ?></p>
    <p><?php _e('Por ejemplo, si quiere mostrar el producto de amazon con el asin B08B99D7FJ, debería usar el shortcode siguiente:', 'no-api-amazon-affiliate') ?></p>
    <code >[amazon asin="B004RG9WAC" template="boton"]</code>
    <br><br>
    <div>
        <img style="border: #e0e0e0; border-style: inset; border-width: 3px;"src="<?php echo NAAA_URL_IMG; ?>boton.PNG" alt="Amazon Asin Url" class="sp-rounded">
    </div>
	
    <h2 class="wp-heading-inline"><?php _e('Tabla Comparativa', 'no-api-amazon-affiliate') ?></h2>
    <p><?php _e('Por ejemplo, si quiere mostrar una tabla comparativa con productos por asin o palabra clave, debería usar el shortcode siguiente:', 'no-api-amazon-affiliate') ?></p>
    <code >[amazon asin="B086R11T4P,B094K481DY,B084TLWG47,B00O2YKL3G,B00XAIQJQ8" template="tabla"] o [amazon bestseller="afeitadoras para hombres" template="tabla" max=5]</code>
    <br><br>
    <div>
        <img style="border: #e0e0e0; border-style: inset; border-width: 3px;"src="<?php echo NAAA_URL_IMG; ?>tabla.png" alt="Tabla comparativo" class="sp-rounded">
    </div>
	
	<h2 class="wp-heading-inline"><?php _e('Estilo Caja Producto', 'no-api-amazon-affiliate') ?></h2>
    <p><?php _e('Por ejemplo, si quiere mostrar una hermosa caja con producto asin, debería usar el shortcode siguiente:', 'no-api-amazon-affiliate') ?></p>
    <code >[amazon asin="B094K481DY" template="caja"] o [amazon bestseller="afeitadoras para hombres" template="caja" max=1] </code>
    <br><br>
    <div>
        <img style="border: #e0e0e0; border-style: inset; border-width: 3px;"src="<?php echo NAAA_URL_IMG; ?>caja.png" alt="caja productero" class="sp-rounded">
    </div>
	
	<h2 class="wp-heading-inline"><?php _e('Estilo Caja amazon', 'no-api-amazon-affiliate') ?></h2>
    <p><?php _e('Por ejemplo, si quiere mostrar una hermosa caja tipo aawp con producto asin, debería usar el shortcode siguiente:', 'no-api-amazon-affiliate') ?></p>
    <code >[amazon asin="B094K481DY" template="caja_amazon"] o [amazon bestseller="afeitadoras para hombres" template="caja" max=1] </code>
    <br><br>
    <div>
        <img style="border: #e0e0e0; border-style: inset; border-width: 3px;"src="<?php echo NAAA_URL_IMG; ?>cajaamazon.png" alt="caja productero" class="sp-rounded">
    </div>
	
	<h2 class="wp-heading-inline"><?php _e('Modulo imagen centrada', 'no-api-amazon-affiliate') ?></h2>
    <p><?php _e('Por ejemplo, si quiere mostrar una imagen centrada, debería usar el shortcode siguiente:', 'no-api-amazon-affiliate') ?></p>
    <code >[amazon asin="B07NFTYTJY" template="imagen_centro"]</code>
    <br><br>
    <div>
        <img style="border: #e0e0e0; border-style: inset; border-width: 3px;"src="<?php echo NAAA_URL_IMG; ?>imagencentro.png" alt="imagen centro" class="sp-rounded">
    </div>
	
	<h2 class="wp-heading-inline"><?php _e('Modulo imagen en lado izquierdo', 'no-api-amazon-affiliate') ?></h2>
    <p><?php _e('Por ejemplo, si quiere mostrar una imagen en lado izquierda, debería usar el shortcode siguiente:', 'no-api-amazon-affiliate') ?></p>
    <code >[amazon asin="B07NFTYTJY" template="imagen_izquierda"]</code>
    <br><br>
    <div>
        <img style="border: #e0e0e0; border-style: inset; border-width: 3px;"src="<?php echo NAAA_URL_IMG; ?>imagenizquierda.png" alt="imagen centro" class="sp-rounded">
    </div>
	
	<h2 class="wp-heading-inline"><?php _e('Modulo imagen en la derecha', 'no-api-amazon-affiliate') ?></h2>
    <p><?php _e('Por ejemplo, si quiere mostrar una imagen en la derecha, debería usar el shortcode siguiente:', 'no-api-amazon-affiliate') ?></p>
    <code >[amazon asin="B07NFTYTJY" template="imagen_derecha"]</code>
    <br><br>
    <div>
        <img style="border: #e0e0e0; border-style: inset; border-width: 3px;"src="<?php echo NAAA_URL_IMG; ?>imagenderecha.png" alt="imagen centro" class="sp-rounded">
    </div>
	
	<h2 class="wp-heading-inline"><?php _e('Poner Producto en Barra Lateral', 'no-api-amazon-affiliate') ?></h2>
    <p><?php _e('recuerda que widget html debes elegir para poner el shortcode, Por ejemplo, si quiere mostrar un producto en la barra lateral, debería usar el shortcode siguiente:', 'no-api-amazon-affiliate') ?></p>
    <code >[amazon asin="B07NFTYTJY" template="widget_vertical"] o [amazon bestseller="afeitadoras para hombres" template="widget_vertical" max=4] </code>
    <br><br>
    <div>
        <img style="border: #e0e0e0; border-style: inset; border-width: 3px;"src="<?php echo NAAA_URL_IMG; ?>productoenbarralateral.png" alt="imagen centro" class="sp-rounded">
    </div>
	
	<h2 class="wp-heading-inline"><?php _e('Estilo Tienda Estilo2 2', 'no-api-amazon-affiliate') ?></h2>
    <p><?php _e('Por ejemplo, si quiere mostrar una hermosa tienda Estilo 2 responsiva con productos por asin, debería usar el shortcode siguiente:', 'no-api-amazon-affiliate') ?></p>
    <code >[amazon asin="B00O2YKL3G,B004RG9WAC,B07RBRSCHB,B01FYFK2R6,B004RG9WBQ,B08DYFPD6F,B01MY79Z0O,B084TM8Q4D" template="tienda2"]</code>
    <br><br>
    <div>
        <img style="border: #e0e0e0; border-style: inset; border-width: 3px;"src="<?php echo NAAA_URL_IMG; ?>Tienda2.png" alt="Tienda2" class="sp-rounded">
    </div>

    <h2 class="wp-heading-inline"><?php _e('Mostrar varios productos', 'no-api-amazon-affiliate') ?></h2>
    <p><?php _e('Para mostrar varios productos indique los códigos ASIN separados con el carácter coma "<strong>,</strong>" tal como se muestra en el ejemplo:', 'no-api-amazon-affiliate') ?></p>
    <code>[amazon asin="B08B99D7FJ, B019U5T9K2, B073VJJRBT"] o [amazon bestseller="afeitadoras para hombres" max=4]</code>
    <br><br>
    <div>
        <img style="border: #e0e0e0; border-style: inset; border-width: 3px;"src="<?php echo NAAA_URL_IMG; ?>tiendaamazon.png" alt="Amazon Asin Url" class="sp-rounded">
    </div>

    <h2 class="wp-heading-inline"><?php _e('Mostrar productos en horizontal', 'no-api-amazon-affiliate') ?></h2>
    <p>
        <?php _e('Para mostrar los productos en horizontal, como si fuera un listado de 1 sola columna.', 'no-api-amazon-affiliate') ?><br>
        <?php _e('Utilizar la propiedad <strong>template="horizontal"</strong> tal como se muestra en el ejemplo:', 'no-api-amazon-affiliate') ?>
    </p>
    <code>[amazon asin="B08B99D7FJ,B01N4OKUB8,B008XI79XW" template="horizontal"] o [amazon bestseller="afeitadoras para hombres" template="horizontal" max=4]</code>
    <br><br>
    <div>
        <img style="border: #e0e0e0; border-style: inset; border-width: 3px;"src="<?php echo NAAA_URL_IMG; ?>horizontal.png" alt="Amazon Product Horizontal" class="sp-rounded">
    </div>
    
	<h2 class="wp-heading-inline"><?php _e('Mostrar productos en Caja Lista', 'no-api-amazon-affiliate') ?></h2>
    <p>
        <?php _e('Para mostrar los productos en caja lista, como si fuera un listado de 1 sola columna.', 'no-api-amazon-affiliate') ?><br>
        <?php _e('Utilizar la propiedad <strong>template="caja_horizontal"</strong> tal como se muestra en el ejemplo:', 'no-api-amazon-affiliate') ?>
    </p>
    <code>[amazon asin="B08B99D7FJ,B01N4OKUB8,B008XI79XW" template="caja_lista"] o [amazon bestseller="afeitadoras para hombres" template="caja_lista" max=4]</code>
    <br><br>
    <div>
        <img style="border: #e0e0e0; border-style: inset; border-width: 3px;"src="<?php echo NAAA_URL_IMG; ?>cajaestilo.png" alt="Amazon Product Horizontal" class="sp-rounded">
    </div>

    <h2 class="wp-heading-inline"><?php _e('Mostrar productos estilo y diferentes marketplace', 'no-api-amazon-affiliate') ?></h2>
    <p>
        <?php _e('Para mostrar productos de un marketplace diferente al default, indique después del código ASIN el indicador de país-marketplace separado con el carácter guion "<strong>-</strong>".', 'no-api-amazon-affiliate') ?><br>
        <?php _e('En el ejemplo podrá observar como el tercer producto pertenece al marketplace de Francia:', 'no-api-amazon-affiliate') ?>
    </p>
    <code>[amazon asin="B08B99D7FJ, B01F9RGJJO, B01APL9AQ8-FR"]</code>
    <br><br>
    <div>
        <img style="border: #e0e0e0; border-style: inset; border-width: 3px;"src="<?php echo NAAA_URL_IMG; ?>tiendaamazon.png" alt="Amazon Asin Url" class="sp-rounded">
    </div>

        <h3 class="wp-heading-inline"><?php _e('Códigos de pais-marketplace', 'no-api-amazon-affiliate') ?></h2>
        <p>
            <?php _e('Los códigos de país-marketplace existentes son:', 'no-api-amazon-affiliate') ?>
        </p>
        <ul>
            <li><?php _e('Amazon Canadá: CA', 'no-api-amazon-affiliate') ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (Ej.=> B01APL9AQ8-CA)</li>
            <li><?php _e('Amazon Alemania: DE', 'no-api-amazon-affiliate') ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (Ej.=> B01APL9AQ8-DE)</li>
            <li><?php _e('Amazon España: ES', 'no-api-amazon-affiliate') ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (Ej.=> B01APL9AQ8-ES)</li>
            <li><?php _e('Amazon Francia: FR', 'no-api-amazon-affiliate') ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (Ej.=> B01APL9AQ8-FR)</li>
            <li><?php _e('Amazon Reino Unido: GB', 'no-api-amazon-affiliate') ?>&nbsp;&nbsp; (Ej.=> B01APL9AQ8-GB)</li>
            <li><?php _e('Amazon Italia: IT', 'no-api-amazon-affiliate') ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (Ej.=> B01APL9AQ8-IT)</li>
            <li><?php _e('Amazon Japón: JP', 'no-api-amazon-affiliate') ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (Ej.=> B01APL9AQ8-JP)</li>
            <li><?php _e('Amazon Estados Unidos: US', 'no-api-amazon-affiliate') ?> (Ej.=> B01APL9AQ8-US)</li>
            <li><del><?php _e('Amazon México: MX', 'no-api-amazon-affiliate') ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (Ej.=> B01APL9AQ8-MX)</del></li>
            <li><del><?php _e('Amazon Brasil: BR', 'no-api-amazon-affiliate') ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (Ej.=> B01APL9AQ8-BR)</del></li>
        </ul>
    </div>
