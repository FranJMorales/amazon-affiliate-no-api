<?php
if (! current_user_can( 'manage_options')) wp_die(_e('No tienes permisos','no-api-amazon-affiliate'));
?>


<div class="wrap">
	<div class="logo-container">
    <a href="https://digitablesolutions.com">
        <img src="<?php echo NAAA_URL_IMG; ?>logo-plugins.png" alt="Plugin Creado Por FJ" style="width: 720px; height: 244px;">
    </a>
</div>
    <h1 class="wp-heading-inline"><?php echo get_admin_page_title() ?></h1>

    <form method="post" action="options.php">
        <?php
            settings_fields( 'naaa-amazon-options2' );
        ?>
        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row"><label for="naaa_tienda_alternativa"><?php _e('QUE TIENDA ALTERNATIVA USARAS', 'no-api-amazon-affiliate') ?></label></th>
                    <td>
                        <select name="naaa_tienda_alternativa" id="tienda_alternativa">
                            <option value="ebay" <?php selected(get_option('naaa_tienda_alternativa', 'si'), 'ebay'); ?>><?php _e('Ebay', 'no-api-amazon-affiliate') ?></option>
							<option value="aliexpress" <?php selected(get_option('naaa_tienda_alternativa', 'si'), 'aliexpress'); ?>><?php _e('Aliexpress', 'no-api-amazon-affiliate') ?></option>
                            <option value="elCorteIngles" <?php selected(get_option('naaa_tienda_alternativa', 'si'), 'elCorteIngles'); ?>><?php _e('elCorteIngles', 'no-api-amazon-affiliate') ?></option>
							<option value="PcComponentes" <?php selected(get_option('naaa_tienda_alternativa', 'si'), 'PcComponentes'); ?>><?php _e('PcComponentes', 'no-api-amazon-affiliate') ?></option>
							<option value="no" <?php selected(get_option('naaa_tienda_alternativa', 'no'), 'no'); ?>><?php _e('NINGUNO', 'no-api-amazon-affiliate') ?></option>
                        </select>
                    </td>
                </tr>
				<tr>
                    <th scope="row"><label for="naaa_boton_tienda_alternativa"><?php _e('Conf. Botón tienda alternativa', 'no-api-amazon-affiliate') ?></label></th>
                    <td>
                        <input name="naaa_boton_tienda_alternativa" type="text" id="naaa_boton_tienda_alternativa" aria-describedby="naaa_boton_tienda_alternativa" value="<?php echo get_option('naaa_boton_tienda_alternativa'); ?>" class="regular-text">
                        <p class="description" id="naaa_boton_tienda_alternativa"><?php _e('Texto dentro del botón de las tiendas alternativas.', 'no-api-amazon-affiliate') ?></p>
                    </td>
                </tr>
        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row"><label for="naaa_num_items_row"><?php _e('Productos por fila, Solo Tienda3', 'no-api-amazon-affiliate') ?></label></th>
                    <td>
                    <fieldset>
                        <input name="naaa_num_items_row" type="number" id="naaa_num_items_row" aria-describedby="naaa_num_items_row_description" value="<?php echo get_option('naaa_num_items_row'); ?>" class="regular-text">
                        <p class="description" id="naaa_num_items_row_description"><?php _e('Número de items por fila.', 'no-api-amazon-affiliate') ?></p>
                        <br>
                    </fieldset>


                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="naaa_num_lines_title"><?php _e('Líneas en título', 'no-api-amazon-affiliate') ?></label></th>
                    <td><input name="naaa_num_lines_title" type="number" id="naaa_num_lines_title" aria-describedby="naaa_num_lines_title_description" value="<?php echo get_option('naaa_num_lines_title'); ?>" class="regular-text">
                    <p class="description" id="naaa_num_lines_title_description"><?php _e('Número de líneas disponibles en el título.', 'no-api-amazon-affiliate') ?></p></td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Mostrar precio', 'no-api-amazon-affiliate') ?></th>
                    <td> 
                        <fieldset>
                            <label for="naaa_precio_new_show">
                                <input name="naaa_precio_new_show" type="checkbox" id="naaa_precio_new_show" value="1" <?php checked( '1', get_option( 'naaa_precio_new_show' ) ); ?> />
                                <?php _e('Mostrar el <strong>precio actual</strong> si esta disponible.', 'no-api-amazon-affiliate') ?>
                            </label>
                            <br>
                            <label for="naaa_precio_old_show">
                                <input name="naaa_precio_old_show" type="checkbox" id="naaa_precio_old_show" value="1" <?php checked( '1', get_option( 'naaa_precio_old_show' ) ); ?> />
                                <?php _e('Mostrar el <strong>precio anterior</strong> si esta disponible.', 'no-api-amazon-affiliate') ?>
                            </label>
                        </fieldset>
                    </td>
                </tr>
<tr>
    <th scope="row"><label for="naaa_button_text"><?php _e('Conf. Botón', 'no-api-amazon-affiliate') ?></label></th>
    <td>
        <input name="naaa_button_text" type="text" id="naaa_button_text" aria-describedby="naaa_button_text_description" value="<?php echo get_option('naaa_button_text', 'Comprar en Amazon'); ?>" class="regular-text">
        <p class="description" id="naaa_button_text_description"><?php _e('Texto dentro del botón.', 'no-api-amazon-affiliate') ?></p>
    </td>
</tr>
<tr>
    <th scope="row"><label for="naaa_button_text_color_caja1"><?php _e('Cambiar el color del boton en estilo Caja', 'no-api-amazon-affiliate') ?></label></th>
    <td>
        <input name="naaa_button_text_color_caja1" type="color" id="naaa_button_text_color_caja1" aria-describedby="naaa_button_text_color_caja1_description" value="<?php echo get_option('naaa_button_text_color_caja1'); ?>" class="regular-text">
        <p class="description" id="naaa_button_text_color_caja1_description"><?php _e('Cambiar el color del boton en estilo Caja.', 'no-api-amazon-affiliate') ?></p>
    </td>
</tr>
<tr>
    <th scope="row"><label for="naaa_button_text_color_caja"><?php _e('Cambiar el color del Texto en estilo Caja', 'no-api-amazon-affiliate') ?></label></th>
    <td>
        <input name="naaa_button_text_color_caja" type="color" id="naaa_button_text_color_caja" aria-describedby="naaa_button_text_color_caja_description" value="<?php echo get_option('naaa_button_text_color_caja'); ?>" class="regular-text">
        <p class="description" id="naaa_button_text_color_caja_description"><?php _e('Cambiar el color del Texto en estilo Caja.', 'no-api-amazon-affiliate') ?></p>
    </td>
</tr>
                <tr>
                    <th scope="row"><label for="naaa_button_text_color"><?php _e('Texto para el descuento en estilo Caja', 'no-api-amazon-affiliate') ?></label></th>
                    <td>
                        <input name="naaa_button_text_color" type="text" id="naaa_button_text_color" aria-describedby="naaa_button_text_color_description" value="<?php echo get_option('naaa_button_text_color'); ?>" class="regular-text">
                        <p class="description" id="naaa_button_text_color_description"><?php _e('Texto para el descuento en estilo Caja.', 'no-api-amazon-affiliate') ?></p>
                    </td>
                </tr>
<tr>
    <th scope="row"><label for="naaa_comentarios_text"><?php _e('Texto para el descuento en Tabla y tienda normal', 'no-api-amazon-affiliate') ?></label></th>
    <td>
        <input name="naaa_comentarios_text" type="text" id="naaa_comentarios_text" aria-describedby="naaa_comentarios_text_description" value="<?php echo get_option('naaa_comentarios_text', 'Descuento Del'); ?>" class="regular-text">
        <p class="description" id="naaa_comentarios_text_description"><?php _e('Texto para el descuento en Tabla y tienda normal.', 'no-api-amazon-affiliate') ?></p>
    </td>
</tr>
<tr>
    <th scope="row"><label for="naaa_button_bg_color"><?php _e('Color del Boton en Tablas', 'no-api-amazon-affiliate') ?></label></th>
    <td>
        <input name="naaa_button_bg_color" type="color" id="naaa_button_bg_color" aria-describedby="naaa_button_bg_color_description" value="<?php echo get_option('naaa_button_bg_color'); ?>" class="regular-text">
        <p class="description" id="naaa_button_bg_color_description"><?php _e(' Para cambiar el Color del Boton en Tablas', 'no-api-amazon-affiliate') ?></p>
    </td>
</tr>
<tr>
    <th scope="row"><label for="naaa_button_bg_color2"><?php _e('Para cambiar el Color del texto en Boton de las Tablas', 'no-api-amazon-affiliate') ?></label></th>
    <td>
        <input name="naaa_button_bg_color2" type="color" id="naaa_button_bg_color2" aria-describedby="naaa_button_bg_color2_description" value="<?php echo get_option('naaa_button_bg_color2'); ?>" class="regular-text">
        <p class="description" id="naaa_button_bg_color2_description"><?php _e(' Para cambiar el Color del texto en Boton de las Tablas', 'no-api-amazon-affiliate') ?></p>
    </td>
</tr>
<tr>
    <th scope="row"><label for="naaa_product_color"><?php _e('Para cambiar Estilo Botones de las Tablas de 1 - 2 o 3', 'no-api-amazon-affiliate') ?></label></th>
    <td>
        <select name="naaa_product_color" id="naaa_product_color" aria-describedby="naaa_product_color_description">
            <option value="1" <?php selected(get_option('naaa_product_color'), '1'); ?>>1</option>
            <option value="2" <?php selected(get_option('naaa_product_color'), '2'); ?>>2</option>
            <option value="3" <?php selected(get_option('naaa_product_color'), '3'); ?>>3</option>
        </select>
        <p class="description" id="naaa_product_color_description"><?php _e(' Para cambiar Estilo Botones de las Tablas de 1 - 2 o 3.', 'no-api-amazon-affiliate') ?></p>
    </td>
</tr>
                <tr>
				<tr>
                    <th scope="row"><label for="naaa_button_bg_color_shadow"><?php _e('Texto por si deja de haber stock en un producto', 'no-api-amazon-affiliate') ?></label></th>
                    <td>
                        <input name="naaa_button_bg_color_shadow" type="text" id="naaa_button_bg_color_shadow" aria-describedby="naaa_button_bg_color_shadow_description" value="<?php echo get_option('naaa_button_bg_color_shadow'); ?>" class="regular-text">
                        <p class="description" id="naaa_button_bg_color_shadow_description"><?php _e(' Texto por si deja de haber stock en un producto.', 'no-api-amazon-affiliate') ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Descuento', 'no-api-amazon-affiliate') ?></th>
                    <td> 
                        <fieldset>
                            <label for="naaa_discount_show">
                                <input name="naaa_discount_show" type="checkbox" id="naaa_discount_show" value="1" <?php checked( '1', get_option( 'naaa_discount_show' ) ); ?> />
                                <?php _e('Mostrar descuento si existe el precio anterior.', 'no-api-amazon-affiliate') ?>
                            </label>
                        </fieldset>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Prime', 'no-api-amazon-affiliate') ?></th>
                    <td> 
                        <fieldset>
                            <label for="naaa_prime_show">
                                <input name="naaa_prime_show" type="checkbox" id="naaa_prime_show" value="1" <?php checked( '1', get_option( 'naaa_prime_show' ) ); ?> />
                                <?php _e('Mostrar etiqueta de los productos Prime.', 'no-api-amazon-affiliate') ?>
                            </label>
                        </fieldset>
                    </td>
                </tr>
            </tbody>
        </table>
        <?php submit_button(); ?>
        
    </form>

<style>
    .wrap {
        background-color: #fff; /* Fondo blanco */
        padding: 20px;
        border: 1px solid #ccc; /* Borde gris */
        font-family: 'Maven Pro', sans-serif; /* Fuente Maven Pro */
    }

    h1.wp-heading-inline {
        font-weight: 700; /* Negrita */
    }

    /* Estilos para el contenedor del logotipo */
    .logo-container {
        text-align: center;
        margin-bottom: 20px;
    }

    /* Estilos para la imagen del logotipo */
    .logo-container img {
        width: 720px;
        height: 144px;
    }

    /* Estilos para los campos de entrada de texto */
    input[type="text"] {
        width: 100%;
        padding: 5px;
        margin-bottom: 10px;
    }

    /* Estilos para el botón de guardar */
    .submit {
        color: #fff; /* Color de texto blanco */
        border: none;
        padding: 10px 20px;
        font-weight: 700; /* Negrita */
    }

    /* Estilos para las etiquetas */
    label {
        font-weight: 700; /* Negrita */
    }

    /* Estilos para las descripciones */
    .description {
        font-style: italic;
    }

    /* Estilos para las tablas */
    .form-table {
        width: 100%;
        margin-top: 20px;
        border-collapse: collapse;
    }

    .form-table th,
    .form-table td {
        padding: 10px;
        border: 1px solid #ccc;
    }

    /* Estilos para los selectores */
    select {
        width: 100%;
        padding: 5px;
    }

    /* Estilos para los checkbox */
    input[type="checkbox"] {
        margin-right: 5px;
    }

    /* Estilos para los colores */
    input[type="color"] {
        width: 100px;
        height: 30px;
        padding: 0;
        border: none;
    }
</style>



</div>