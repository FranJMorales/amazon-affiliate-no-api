=== Amazon Affiliate NO API ===
Contributors: FJ
Tags: Amazon, Afiliados, Amazon afiliados, Amazon affiliate, affiliate, sin api, AWS keys, no amazon api, Amazon associates, amazon product search, amazon link, amazon api
Requires at least: 5.5
Tested up to: 5.9.3
Stable tag: 4.2.0
Requires PHP: 5.6.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin para mostrar productos de Amazon con tu ID de afiliado sin la necesidad de utilizar la API  de Amazon (Muy útil para los que están recién comenzando en la afiliación con Amazon)

Agregue productos de Amazon formateados a cualquier página o publicación usando solo la identificación del producto ASIN, sin programación. Sin claves de Amazon AWS, sin código, sin conocimiento de css.

La mejor opción para los programas de afiliados de Amazon o otros Marketplace.

Caracteristicas Del Amazon Affiliate Pro

➡️ Sin limitaciones de usos
➡️ Actualizaciones de por vida
➡️ Widgets de Amazon
➡️ Responsive Mobile
➡️ SEO-Friendly
➡️ Amazon caché
➡️ Optimizado para la conversión
➡️ Instalación ultra fácil y rápida.
➡️ No se requieren conocimientos de programación ni css.
➡️ Múltiples tiendas Marketplace.
➡️ Actualización automática de precios.
➡️ Muestre sus productos usando distintas plantillas.
➡️ Datos consultados guardados automáticamente. Carga la página más rápido.
➡️ Rel patrocinado, enlace No-follow, según la política de Google y Amazon.
➡️ Se puede hacer clic en todos los cuadros, no pierda clics al no hacer clic en el botón.
➡️ Configure el título del producto manualmente, diferente del producto de Amazon.
➡️ Establezca el color del texto para la caja del producto.
➡️ Establezca el número de productos (MAXIMO 10 LO QUE OFRECE AMAZON). Configuración receptiva o no receptiva.
➡️ Mostrar u ocultar el precio.
➡️ Mostrar u ocultar el último precio.
➡️ Establezca el texto del botón de llamada a la acción.
➡️ Establezca el color y el degradado del botón.
➡️ Muestra u oculta la etiqueta de descuento y configúralo.
➡️ Mostrar u ocultar la etiqueta principal de Amazon.
➡️ Compatibilidad con temas (Orbital, Wasabi Theme y Asap Theme)

➡️ Orientado 100% al SEO 📈

Amazon Affiliate Pro esta diseñado exclusivamente para ser lo más SEO-Friendly posible, para que vuestra web sea PERFECTA a los ojos de Google y otros buscadores.

➡️ Productos Cacheados 🛠

Podrás cachear la llamada de Amazon, para que no haga tantas peticiones por segundo.

Si tienes muchas webs, o muchas visitas, olvídate de la API de Amazon que se queman tus peticiones, que tienes que vender cada cierto tiempo y te quitan la API, ahora tendrás productos SIEMPRE disponibles para el usuario SIN LA API DE AMAZON Y TODO ACTUALIZADO.