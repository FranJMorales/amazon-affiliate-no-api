jQuery(document).ready(function($) {

  $('#naaa_button_add_item_amazon').click(function(){
    $('#addAmazonItemModal').modal('show');
  });

  $('.naaa_btn_edit').click(function(){
    var id_naaa_item_amazon = this.dataset.id;
    var asin = this.dataset.asin;
    var title = this.dataset.title;
    var title_manual = this.dataset.title_manual;
    

    $('#editAmazonItemAsinTitle').html(asin);
    $('#naaa_id_title_item').val(id_naaa_item_amazon);
    $('#naaa_title_item').val(title);
    if(title_manual && title_manual.trim()!= ""){
      $('#naaa_title_manual_item').val(title_manual);
    }else{
      $('#naaa_title_manual_item').val('');
    }
    $('#editAmazonItemModal').modal('show');
  });


  $('.naaa_btn_update').click(function(){
    var asin = this.dataset.asin;
    var market = this.dataset.market;
    var url = ajax_object.url;
    $.ajax({
      type: "POST",
      url: url,
      data:{
        action : "naaa_update_by_asin",
        nonce : ajax_object.seguridad,
        asin : asin,
        market: market
      },
      success: function(response){
        alert(response);
        location.reload();  
      }
    });
  });

  $('.naaa_btn_delete').click(function(){
    var asin = this.dataset.asin;
    var market = this.dataset.market;
    var url = ajax_object.url;
    $.ajax({
      type: "POST",
      url: url,
      data:{
        action : "naaa_delete_by_asin",
        nonce : ajax_object.seguridad,
        asin : asin,
        market : market
      },
      success: function(response){
        alert(response);
        location.reload();  
      }
    });
  });

});