(function () {
    function showPrompt(title, hint, shortcode, editor) {
        var result = prompt(title, hint);

        if (result != null) {
            if (result !== hint) {
                editor.execCommand('mceInsertContent', false, shortcode.replace(hint, result));
            } else {
                alert('Debes ingresar un ' + title + ' válido');
            }
        }
    }

    tinymce.PluginManager.add('rap_button', function (editor, url) {
        editor.addButton('rap_button', {
            title: 'Insertar shortcode',
            icon: true,
            image: '/wp-content/plugins/rap/public/images/icon16.png',
            type: 'menubutton',
            menu: [
                {
                    text: 'Módulo Caja',
                    onclick: function () {
                        showPrompt("ASIN de Amazon", "ASIN_AMAZON", "[rap asin='ASIN_AMAZON']", editor);
                    }
                },
                {
                    text: 'Módulo Tabla',
                    onclick: function () {
                        showPrompt("Id de la tabla", "ID_TABLA", "[raptabla id='ID_TABLA']", editor);
                    }
                },
                {
                    text: 'Módulo Tienda',
                    onclick: function () {
                        showPrompt("Nombre de producto", "Palabra Clave del Producto", "[raptienda asin='Palabra Clave del Producto']", editor);
                    }
                },
                {
                    text: 'Módulo Imagen',
                    onclick: function () {
                        showPrompt("ASIN de Amazon", "ASIN_AMAZON", "[rapimagen asin='ASIN_AMAZON']", editor);
                    }
                }
            ]
        });
    });
})();
