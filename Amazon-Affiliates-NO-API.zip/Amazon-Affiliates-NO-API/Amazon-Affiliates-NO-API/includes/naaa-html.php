<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

function naaa_get_html_review_h($opiniones) {
	if (!get_option('naaa_comentarios_show')){
		return '';
	}

	$numOpiniones = naaa_get_numeric($opiniones);
	if ($numOpiniones > 99999 ){
		$opiniones = '+100k';
	}

	$naaa_html_review = '<span class="naaa-product-review">';
		$naaa_html_review .= '<span class="naaa-product-review-value">('.esc_html($opiniones).')</span>';
		$naaa_html_review .= '<span class="naaa-product-review-text-h">'.esc_html(get_option('naaa_comentarios_text')).'</span>';
	$naaa_html_review .= '</span>';

	return $naaa_html_review;
}

function naaa_get_html_review($opiniones) {
	if (!get_option('naaa_comentarios_show')){
		return '';
	}

	$numOpiniones = naaa_get_numeric($opiniones);
	if ($numOpiniones > 99999 ){
		$opiniones = '+100k';
	}

	$naaa_html_review = '<div class="naaa-product-review">';
		$naaa_html_review .= '<div class="naaa-product-review-value">('.esc_html($opiniones).')</div>';
		$naaa_html_review .= '<div class="naaa-product-review-text">'.esc_html(get_option('naaa_comentarios_text')).'</div>';
	$naaa_html_review .= '</div>';

	return $naaa_html_review;
}

function naaa_get_html_rating_h($valoracion){
	if (!get_option('naaa_valoracion_show', 1)){
		return '<span class="naaa-product-no-rating"></span>';
	}

	$starSegment = round(($valoracion / 0.5));
	if ($valoracion > 0){
		$title = $valoracion.' '.__('de', 'no-api-amazon-affiliate').' 5';
		$title = esc_html($title);
	}else{
		$title = esc_html(__('Sin valorar', 'no-api-amazon-affiliate'));
	}

	$nameGroup = uniqid();
	$naaa_html_rating = '<span class="naaa-product-rating">';
		$naaa_html_rating .= '<fieldset class="naaa-rating" id="'.$nameGroup.'">';
		for ($i=10; $i > 1 ; $i--) { 
			if($i%2==0){
				$naaa_html_rating .= '<input type="radio" class="naaa-input-star" name="'.$nameGroup.'" value="'.$i.'" '.checked($i, $starSegment, false).'/><label class="naaa-full naaa-label-star" title="'.$title.'"></label>';
			}else{
				$naaa_html_rating .= '<input type="radio" class="naaa-input-star" name="'.$nameGroup.'" value="'.$i.'" '.checked($i, $starSegment, false).'/><label class="naaa-half naaa-label-star" title="'.$title.'"></label>';
			}
		}
		$naaa_html_rating .= '</fieldset>';
		if (get_option('naaa_valoracion_desc_show')){
			$naaa_html_rating .= '<span class="naaa-product-rating-value-h" title="'.$title.'">'.$title.'</span>';
		}else{
			$naaa_html_rating .= '<span class="naaa-product-rating-value-h" title="'.$title.'">&nbsp;</span>';
		}
	$naaa_html_rating .= '</span>';
	
	return $naaa_html_rating;
}

function naaa_get_html_rating($valoracion){
	if (!get_option('naaa_valoracion_show', 1)){
		return '<div class="naaa-product-no-rating"></div>';
	}

	$starSegment = round(($valoracion / 0.5));
	if ($valoracion > 0){
		$title = $valoracion.' '.__('de', 'no-api-amazon-affiliate').' 5';
		$title = esc_html($title);
	}else{
		$title = esc_html(__('Sin valorar', 'no-api-amazon-affiliate'));
	}

	$nameGroup = uniqid();
	$naaa_html_rating = '<div class="naaa-product-rating">';
		$naaa_html_rating .= '<fieldset class="naaa-rating" id="'.$nameGroup.'">';
		for ($i=10; $i > 1 ; $i--) { 
			if($i%2==0){
				$naaa_html_rating .= '<input type="radio" class="naaa-input-star" name="'.$nameGroup.'" value="'.$i.'" '.checked($i, $starSegment, false).'/><label class="naaa-full naaa-label-star" title="'.$title.'"></label>';
			}else{
				$naaa_html_rating .= '<input type="radio" class="naaa-input-star" name="'.$nameGroup.'" value="'.$i.'" '.checked($i, $starSegment, false).'/><label class="naaa-half naaa-label-star" title="'.$title.'"></label>';
			}
		}
		$naaa_html_rating .= '</fieldset>';
		if (get_option('naaa_valoracion_desc_show')){
			$naaa_html_rating .= '<div class="naaa-product-rating-value" title="'.$title.'">'.$title.'</div>';
		}
	$naaa_html_rating .= '</div>';
	
	return $naaa_html_rating;
}

function naaa_get_html_discount($precio, $precio_old){
	if (empty($precio) || empty($precio_old) || !get_option('naaa_discount_show', 1) || $precio == 0 || $precio_old == 0){
		return '';
	}

	$discount = intval(100-( (100*$precio)/($precio_old) ));
	
	$naaa_html_discount = '<div class="naaa-discount">'.esc_html($discount).'%</div>';
	return $naaa_html_discount;
}

function naaa_get_html_descuentoTabla($precio, $precio_old){
	if (empty($precio) || empty($precio_old) || !get_option('naaa_discount_show', 1) || $precio == 0 || $precio_old == 0){
		return '';
	}

	$discount = intval(100-( (100*$precio)/($precio_old) ));
	$DESCUENTOE=get_option('naaa_comentarios_text');
	$naaa_html_descuentoTabla = '<div class="naaa-descuentoTabla">'.$DESCUENTOE.' '.esc_html($discount).'%</div>';
	return $naaa_html_descuentoTabla;
}
function naaa_get_html_descuentoTabla1($precio, $precio_old){
	if (empty($precio) || empty($precio_old) || !get_option('naaa_discount_show', 1) || $precio == 0 || $precio_old == 0){
		return '';
	}

	$discount = intval(100-( (100*$precio)/($precio_old) ));
	$DESCUENTOE=get_option('naaa_comentarios_text');
	$naaa_html_descuentoTabla1 = '<div class="ribbon"><span style="color:#FFFFFF; background-color:#3dc41f;">'.$DESCUENTOE.' '.esc_html($discount).'%</span></div>';
	return $naaa_html_descuentoTabla1;
}
function naaa_get_html_descuentocaja($precio, $precio_old){
	if (empty($precio) || empty($precio_old) || !get_option('naaa_discount_show', 1) || $precio == 0 || $precio_old == 0){
		return '';
	}

	$discount = intval(100-( (100*$precio)/($precio_old) ));
	$DESCUENTOE=get_option('naaa_button_text_color');
	$naaa_html_descuentocaja = ''.$DESCUENTOE.' '.esc_html($discount).'%';
	return $naaa_html_descuentocaja;
}
function naaa_get_html_descuentocaja2($precio, $precio_old){
	if (empty($precio) || empty($precio_old) || !get_option('naaa_discount_show', 1) || $precio == 0 || $precio_old == 0){
		return '';
	}

	$discount = intval(100-( (100*$precio)/($precio_old) ));
	$DESCUENTOE=get_option('naaa_button_text_color');
	$naaa_html_descuentocaja2 = '<strong>'.$DESCUENTOE.' '.esc_html($discount).'%</strong>';
	return $naaa_html_descuentocaja2;
}
function naaa_get_html_descuentoTienda($precio, $precio_old){
	if (empty($precio) || empty($precio_old) || !get_option('naaa_discount_show', 1) || $precio == 0 || $precio_old == 0){
		return '';
	}

	$discount = intval(100-( (100*$precio)/($precio_old) ));
	
	$naaa_html_descuentoTienda = ''.esc_html($discount).'% DESCUENTO';
	return $naaa_html_descuentoTienda;
}
function naaa_get_html_descuentoTienda3($precio, $precio_old){
	if (empty($precio) || empty($precio_old) || !get_option('naaa_discount_show', 1) || $precio == 0 || $precio_old == 0){
		return '';
	}

	$discount = intval(100-( (100*$precio)/($precio_old) ));
	$DESCUENTOE=get_option('naaa_comentarios_text');
	$naaa_html_descuentoTienda3 =''.$DESCUENTOE.' '.esc_html($discount).'%';
	return $naaa_html_descuentoTienda3;
}
function naaa_get_html_price($precio, $market, $precio_text, $precio_old, $template){
    $preciodisponible= get_option('naaa_button_bg_color_shadow');
	if (!get_option('naaa_precio_new_show', 1) && !get_option('naaa_precio_old_show', 1) ){
		return '';
	}
	
	$naaa_show_precio_new  = !empty($precio) && ($precio>0) && get_option('naaa_precio_new_show', 1);
	$naaa_show_precio_old  = !empty($precio_old) && ($precio_old>0) && get_option('naaa_precio_old_show', 1);

	$naaa_html_price = '<div class="naaa-product-price">';
		if(!empty($precio_text) && ($naaa_show_precio_new || $naaa_show_precio_old) ){
			$naaa_html_price .= '<div class="naaa-product-price-text">'.esc_html($precio_text).'</div>&nbsp;';
		}if($precio == 0){
			$naaa_html_price .= ''.$preciodisponible.'';
		}

		if($template == 'horizontal'){
			$naaa_html_price .= '<div class="naaa-product-price-h">';
		}else{
			$naaa_html_price .= '<div>';
		}
			if($naaa_show_precio_new){
				$naaa_html_price .= '<span class="naaa-product-price-new">'.esc_html(naaa_get_price_with_currency($precio, $market)).'</span>&nbsp;';
			}

			if($naaa_show_precio_old){
				$naaa_html_price .= '<span class="naaa-product-price-old">'.esc_html(naaa_get_price_with_currency($precio_old, $market)).'</span>';
			}
		$naaa_html_price .= '</div>';

	$naaa_html_price .= '</div>';

	return $naaa_html_price;
}
function naaa_get_html_prime($prime){
	if (empty($prime) || !get_option('naaa_prime_show', 1)){
		return '';
	}
	$naaa_html_prime = '<span class="naaa-prime"></span>';
	return $naaa_html_prime;
}

function naaa_get_html_primeHorizontal($prime){
	if (empty($prime) || !get_option('naaa_prime_show', 1)){
		return '';
	}
	$naaa_html_primeHorizontal = 'aawp-check-prime';
	return $naaa_html_primeHorizontal;
}
function naaa_get_html_primeTienda2($prime){
	if (empty($prime) || !get_option('naaa_prime_show', 1)){
		$naaa_html_primeTienda2 = '<span class="naaa-noprime"></span>';
	}else{
		$naaa_html_primeTienda2 = '<span class="naaa-primeTienda2"></span>';
	}
	return $naaa_html_primeTienda2;
}

function naaa_get_html_primeTabla($prime){
	if (empty($prime) || !get_option('naaa_prime_show', 1)){
		$naaa_html_primeTabla = '<span class="naaa-noprime"></span>';
	}else{
	$naaa_html_primeTabla = '<span class="naaa-primeTienda2"></span>';
	}
	return $naaa_html_primeTabla;
}

function naaa_get_html_button($button_text){
	$naaa_html_button = '<div class="naaa-product-action">';
		if (get_option('naaa_button_border_show', 1)){
			$naaa_html_button .= '<div class="naaa-product-button naaa-product-button-border">'.esc_html($button_text).'</div>';
		}else{
			$naaa_html_button .= '<div class="naaa-product-button">'.esc_html($button_text).'</div>';
		}
	$naaa_html_button .= '</div>';
	return $naaa_html_button;
}

function naaa_get_html_class_gridbox(){
	if (!get_option('naaa_responsive', 1)){
		return 'naaa-gridbox';
	}else{
		return 'naaa-gridbox naaa-responsive';
	}
}

function naaa_get_html_gridbox($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market, $template){
	if($template == 'horizontal'){
		return naaa_get_html_gridbox_hori($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market);
	}if($template == 'tabla'){
		return naaa_get_html_gridbox_tabla($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market);
	}if($template == 'caja'){
		return naaa_get_html_gridbox_caja($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market);
	}if($template == 'tienda2'){
		return naaa_get_html_gridbox_tienda2($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market);
	}if($template == 'imagen_izquierda'){
		return naaa_get_html_gridbox_imagen_izquierda($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market);
	}if($template == 'imagen_derecha'){
		return naaa_get_html_gridbox_imagen_derecha($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market);
	}if($template == 'imagen_centro'){
		return naaa_get_html_gridbox_imagen_centro($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market);
	}if($template == 'caja_lista'){
		return naaa_get_html_gridbox_caja_lista($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market);
	}if($template == 'caja_amazon'){
		return naaa_get_html_gridbox_caja_amazon($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market);
	}if($template == 'widget_vertical'){
		return naaa_get_html_gridbox_widget_vertical($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market);
	}if($template == 'boton'){
		return naaa_get_html_gridbox_boton($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market);
	}else{
		return naaa_get_html_gridbox_card($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market);
	}
}

function naaa_get_html_gridbox_boton($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market){
	$naaa_html_gridbox = '<a href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" target="_blank" rel="nofollow noopener sponsored" class="cta cta-style-2"><svg xmlns="http://www.w3.org/2000/svg" aria-label="Amazon" class="data-source-icon" xml:space="preserve" viewBox="0 0 512 512"><path d="M259.2 12.3c-67.3 0-140.7 24.5-157.1 108.1-2 8.2 4.1 14.3 10.2 14.3l67.3 6.1c6.1 0 12.2-6.1 12.2-12.2C198 100 222.5 85.7 249 85.7c14.3 0 30.6 6.1 38.8 18.4 10.2 14.3 8.2 34.7 8.2 51v10.2c-40.8 4.1-93.8 8.2-132.6 24.5-44.9 18.4-75.5 57.1-75.5 116.3 0 73.4 46.9 110.1 106.1 110.1 51 0 77.5-12.2 116.3-51 12.2 18.4 18.4 28.6 40.8 46.9 6.1 2 12.2 2 16.3-2 14.3-12.2 40.8-34.7 55.1-46.9 6.1-4.1 4.1-12.2 0-18.4-12.2-18.4-26.5-32.6-26.5-65.3V169.3c0-46.9 4.1-89.8-30.6-122.4-26.6-26.5-71.5-34.6-106.2-34.6zm18.4 210H296v16.3c0 26.5 2 51-12.2 75.5-10.2 20.4-28.6 32.6-49 32.6-26.5 0-42.8-20.4-42.8-51-.1-55 40.7-69.3 85.6-73.4zm195.8 165.3c-18.4 0-38.8 4.1-55.1 16.3-4.1 4.1-4.1 8.2 2 8.2 18.4-2 57.1-8.2 65.3 2 8.2 10.2-8.2 46.9-14.3 63.2-2 4.1 2 6.1 6.1 4.1 30.6-24.5 38.8-77.5 32.6-85.7-4-6.1-18.2-8.1-36.6-8.1zM4.3 395.7c-4.1 0-6.1 6.1-2 8.2 67.3 61.2 155 95.9 252.9 95.9 69.3 0 150.9-22.4 208.1-63.2 10.2-6.1 2-18.4-8.2-14.3-63.3 26.5-130.6 38.7-193.8 38.7-91.8 0-179.5-24.5-252.9-67.3-2.1 4.1-4.1 2-4.1 2z"></path></svg>'.esc_html($button_text).'</a>';
	return $naaa_html_gridbox;
}
function naaa_get_html_gridbox_caja_amazon($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market){
	$naaa_html_gridbox = '<div class="aawp-product aawp-product--horizontal aawp-product--ribbon aawp-product--sale aawp-product--bestseller" data-aawp-product-id="" data-aawp-product-title="" data-aawp-click-tracking="title">
      <span class="aawp-product__ribbon aawp-product__ribbon--sale">'.naaa_get_html_descuentoTienda3($precio, $precio_old).'</span>
      <div class="aawp-product__thumb">
         <a class="aawp-product__image-link" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="'.$titulo.'" rel="nofollow noopener sponsored" target="_blank">
         <img class="aawp-product__image" src="'.esc_url($urlImage.'_AC_AC_SR160,160_.jpg').'" alt="'.$titulo.'">
         </a>
      </div>
      <div class="aawp-product__content">
         <a class="aawp-product__title" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="'.$titulo.'" rel="nofollow noopener sponsored" target="_blank">'.$titulo.'</a>
      </div>
      <div class="aawp-product__footer">
         <div class="aawp-product__pricing">
            <span class="aawp-product__price aawp-product__price--current">'.naaa_get_html_price($precio, $market, $precio_text, $precio_old, 'card').'</span>
            <a class="'.naaa_get_html_primeHorizontal($prime).'" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="Amazon Prime" rel="nofollow noopener sponsored" target="_blank"></a>        
         </div>
         <a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon aawp-button--icon aawp-button--icon-amazon-black" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="Comprar en Amazon" target="_blank" rel="nofollow noopener sponsored">'.esc_html($button_text).'</a>
      </div>
   </div>';
	return $naaa_html_gridbox;					
}
function naaa_get_html_gridbox_card($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market){
	$OtraTienda= get_option('naaa_tienda_alternativa');
	if($OtraTienda == "ebay"){
	$idebay= get_option('naaa_tag_ebay');
	$texto_boton= get_option('naaa_boton_tienda_alternativa');
	$estiloboton= get_option('naaa_product_color');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
    $titulo2= trim(substr($titulo, 0, 37));
	$OtraTienda='<div class="aawp_amazon"> <img alt="Amazon" title="Amazon" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-amazon.png" class="imagen1_margin"> </div>
<div class="aawp_amazon"> <img class="imagen_margin" alt="ebay" title="ebay" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-ebay.png"> </div>
<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon aawp-button--icon aawp-button--icon-amazon-white" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important;" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="Amazon" target="_blank" rel="nofollow noopener sponsored">'.esc_html($button_text).'</a>
<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon rounded shadow aawp-button--icon aawp-button--icon-white" href="https://www.ebay.es/sch/i.html?_from=R40&_nkw='.$titulo2.'&_sacat=0&customid='.$idebay.'" title="ebay" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important;" target="_blank" rel="nofollow noopener sponsored">'.$texto_boton.'</a>';
	}
	else if($OtraTienda == "aliexpress"){
	$idaliexpress= get_option('naaa_tag_aliexpress');
	$estiloboton= get_option('naaa_product_color');
	$texto_boton= get_option('naaa_boton_tienda_alternativa');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
    $titulo2= trim(substr($titulo, 0, 37));
	$OtraTienda='<div class="aawp_amazon"> <img alt="Amazon" title="Amazon" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-amazon.png" class="imagen1_margin"> </div>
<div class="aawp_amazon"> <img class="imagen_margin" alt="Aliexpress" title="Aliexpress" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-aliexpress.png"> </div>
<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon aawp-button--icon aawp-button--icon-amazon-white" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important;" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="Amazon" target="_blank" rel="nofollow noopener sponsored">'.esc_html($button_text).'</a>
<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon rounded shadow aawp-button--icon aawp-button--icon-white" href="https://es.aliexpress.com/af/aliexpress.html?d=y&origin=n&SearchText='.$titulo2.'&?dp='.$idaliexpress.'" title="aliexpress" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important;" target="_blank" rel="nofollow noopener sponsored">'.$texto_boton.'</a>';
	}
	else if($OtraTienda == "elCorteIngles"){
	$idawin= get_option('naaa_tag_elCorteIngles');
	$estiloboton= get_option('naaa_product_color');
	$texto_boton= get_option('naaa_boton_tienda_alternativa');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
    $titulo2= trim(substr($titulo, 0, 37));
	$OtraTienda='<div class="aawp_amazon"> <img alt="Amazon" title="Amazon" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-amazon.png" class="imagen1_margin"> </div>
<div class="aawp_amazon"> <img class="imagen_margin" alt="ElCorteIngles" title="ElCorteIngles" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-elcorteingles1.png"> </div>
<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon aawp-button--icon aawp-button--icon-amazon-white" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important;" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="Amazon" target="_blank" rel="nofollow noopener sponsored">'.esc_html($button_text).'</a>
<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon rounded shadow aawp-button--icon aawp-button--icon-white" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important;" href="'.$idawin.'https://www.elcorteingles.es/search/?s='.$titulo2.'&hierarchy=&deep_search=&stype=text_box" title="elCorteIngles" target="_blank" rel="nofollow noopener sponsored">'.$texto_boton.'</a>';
	}
	else if($OtraTienda == "PcComponentes"){
	$idawin= get_option('naaa_tag_PcComponentes');
	$estiloboton= get_option('naaa_product_color');
	$texto_boton= get_option('naaa_boton_tienda_alternativa');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
    $titulo2= trim(substr($titulo, 0, 37));
	$OtraTienda='<div class="aawp_amazon"> <img alt="Amazon" title="Amazon" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-amazon.png" class="imagen1_margin"> </div>
<div class="aawp_amazon"> <img class="imagen_margin" alt="PcComponentes" title="PcComponentes" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-PcComponentes.png"> </div>
<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon aawp-button--icon aawp-button--icon-amazon-white" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important;" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="Amazon" target="_blank" rel="nofollow noopener sponsored">'.esc_html($button_text).'</a>
<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon rounded shadow aawp-button--icon aawp-button--icon-white" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important;" href="'.$idawin.'https://www.pccomponentes.com/buscar/?query='.$titulo2.'&page=1&or-relevance" title="PcComponentes" target="_blank" rel="nofollow noopener sponsored">'.$texto_boton.'</a>';
	}
	else if($OtraTienda == "no"){
	$estiloboton= get_option('naaa_product_color');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
	$OtraTienda='<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon aawp-button--icon aawp-button--icon-amazon-white" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="'.esc_html($button_text).'" target="_blank" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important; border-radius: 15px; width: 100%;" rel="nofollow noopener sponsored">'.esc_html($button_text).'</a>';
	}
	$naaa_html_gridbox = '<div class="aawp-grid__item">
         <div class="aawp-product aawp-product--vertical aawp-product--ribbon aawp-product--sale aawp-product--bestseller" data-aawp-product-id="" data-aawp-product-title="'.$titulo.'" data-aawp-click-tracking="title">
            <span class="aawp-product__ribbon aawp-product__ribbon--sale">'.naaa_get_html_descuentoTienda3($precio, $precio_old).'</span>
            <a class="aawp-product__image--link aawp-product__image" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="'.$titulo.'" rel="nofollow noopener sponsored" target="_blank">
            <img class="aawp-product__image" src="'.esc_url($urlImage.'_AC_AC_SR250,250_.jpg').'" alt="'.$titulo.'" title="'.$titulo.'">
            </a>
            <div class="aawp-product__content">
               <a class="aawp-product__title" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="'.$titulo.'" rel="nofollow noopener sponsored" target="_blank">'.$titulo.'</a>
               <div class="aawp-product__meta">
                  <a class="'.naaa_get_html_primeHorizontal($prime).'" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" rel="nofollow noopener sponsored" target="_blank"></a>        
               </div>
            </div>
            <div class="aawp-product__footer">
               <div class="aawp-product__pricing">
                  <span class="aawp-product__price aawp-product__price--current">'.naaa_get_html_price($precio, $market, $precio_text, $precio_old, 'card').'</span>
               </div>
			  '.$OtraTienda.'
            </div>
         </div>
      </div>';
	return $naaa_html_gridbox;					
}
function naaa_get_html_gridbox_widget_vertical($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market){
	$OtraTienda= get_option('naaa_tienda_alternativa');
	if($OtraTienda == "ebay"){
	$idebay= get_option('naaa_tag_ebay');
	$texto_boton= get_option('naaa_boton_tienda_alternativa');
	$estiloboton= get_option('naaa_product_color');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
    $titulo2= trim(substr($titulo, 0, 37));
	$OtraTienda='<div class="aawp_amazon"> <img alt="Amazon" title="Amazon" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-amazon.png" class="imagen1_margin"> </div>
<div class="aawp_amazon"> <img class="imagen_margin_lateral" alt="ebay" title="ebay" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-ebay.png"> </div>
<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon aawp-button--icon aawp-button--icon-amazon-white" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important; border-radius: 15px;" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="Amazon" target="_blank" rel="nofollow noopener sponsored">'.esc_html($button_text).'</a>
<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon rounded shadow aawp-button--icon aawp-button--icon-white" href="https://www.ebay.es/sch/i.html?_from=R40&_nkw='.$titulo2.'&_sacat=0&customid='.$idebay.'" title="ebay" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important;  margin-left: 20px!important; border-radius: 15px;" target="_blank" rel="nofollow noopener sponsored">'.$texto_boton.'</a>';
	}
	else if($OtraTienda == "aliexpress"){
	$idaliexpress= get_option('naaa_tag_aliexpress');
	$estiloboton= get_option('naaa_product_color');
	$texto_boton= get_option('naaa_boton_tienda_alternativa');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
    $titulo2= trim(substr($titulo, 0, 37));
	$OtraTienda='<div class="aawp_amazon"> <img alt="Amazon" title="Amazon" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-amazon.png" class="imagen1_margin"> </div>
<div class="aawp_amazon"> <img class="imagen_margin_lateral" alt="Aliexpress" title="Aliexpress" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-aliexpress.png"> </div>
<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon aawp-button--icon aawp-button--icon-amazon-white" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important; border-radius: 15px;" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="Amazon" target="_blank" rel="nofollow noopener sponsored">'.esc_html($button_text).'</a>
<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon rounded shadow aawp-button--icon aawp-button--icon-white" href="https://es.aliexpress.com/af/aliexpress.html?d=y&origin=n&SearchText='.$titulo2.'&?dp='.$idaliexpress.'" title="aliexpress" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important;  margin-left: 20px!important; border-radius: 15px;" target="_blank" rel="nofollow noopener sponsored">'.$texto_boton.'</a>';
	}
	else if($OtraTienda == "elCorteIngles"){
	$idawin= get_option('naaa_tag_elCorteIngles');
	$estiloboton= get_option('naaa_product_color');
	$texto_boton= get_option('naaa_boton_tienda_alternativa');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
    $titulo2= trim(substr($titulo, 0, 37));
	$OtraTienda='<div class="aawp_amazon"> <img alt="Amazon" title="Amazon" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-amazon.png" class="imagen1_margin"> </div>
<div class="aawp_amazon"> <img class="imagen_margin_lateral" alt="ElCorteIngles" title="ElCorteIngles" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-elcorteingles1.png"> </div>
<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon aawp-button--icon aawp-button--icon-amazon-white" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important; border-radius: 15px;" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="Amazon" target="_blank" rel="nofollow noopener sponsored">'.esc_html($button_text).'</a>
<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon rounded shadow aawp-button--icon aawp-button--icon-white" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important;  margin-left: 20px!important; border-radius: 15px;" href="'.$idawin.'https://www.elcorteingles.es/search/?s='.$titulo2.'&hierarchy=&deep_search=&stype=text_box" title="elCorteIngles" target="_blank" rel="nofollow noopener sponsored">'.$texto_boton.'</a>';
	}
	else if($OtraTienda == "PcComponentes"){
	$idawin= get_option('naaa_tag_PcComponentes');
	$estiloboton= get_option('naaa_product_color');
	$texto_boton= get_option('naaa_boton_tienda_alternativa');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
    $titulo2= trim(substr($titulo, 0, 37));
	$OtraTienda='<div class="aawp_amazon"> <img alt="Amazon" title="Amazon" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-amazon.png" class="imagen1_margin"> </div>
<div class="aawp_amazon"> <img class="imagen_margin_lateral" alt="PcComponentes" title="PcComponentes" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-PcComponentes.png"> </div>
<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon aawp-button--icon aawp-button--icon-amazon-white" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important; border-radius: 15px;" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="Amazon" target="_blank" rel="nofollow noopener sponsored">'.esc_html($button_text).'</a>
<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon rounded shadow aawp-button--icon aawp-button--icon-white" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important;  margin-left: 20px!important; border-radius: 15px;" href="'.$idawin.'https://www.pccomponentes.com/buscar/?query='.$titulo2.'&page=1&or-relevance" title="PcComponentes" target="_blank" rel="nofollow noopener sponsored">'.$texto_boton.'</a>';
	}
	else if($OtraTienda == "no"){
	$estiloboton= get_option('naaa_product_color');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
	$OtraTienda='<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon aawp-button--icon aawp-button--icon-amazon-white" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="'.esc_html($button_text).'" target="_blank" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important; border-radius: 15px; margin-right: 0px;" rel="nofollow noopener sponsored">'.esc_html($button_text).'</a>';
	}
	$naaa_html_gridbox = '<div class="aawp aawp-widget"><div class="aawp-product aawp-product--widget-vertical aawp-product--style-light aawp-product--bestseller aawp-product--ribbon" data-aawp-product-id="" data-aawp-product-title="">
	   <span class="aawp-product__ribbon aawp-product__ribbon--sale">'.naaa_get_html_descuentoTienda3($precio, $precio_old).'</span>
      <a class="aawp-product__image-link" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="'.$titulo.'" rel="nofollow noopener sponsored" target="_blank">
      <img class="aawp-product__image" src="'.esc_url($urlImage.'_AC_AC_SR250,250_.jpg').'" alt="'.$titulo.'">
      </a>
      <div class="aawp-product__content">
         <a class="aawp-product__title" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="'.$titulo.'" rel="nofollow noopener sponsored" target="_blank">'.$titulo.'</a>
         <div class="aawp-product__meta"></div>
      </div>
      <div class="aawp-product__footer">
        <div class="aawp-product__pricing">
            <span class="aawp-product__price aawp-product__price--current">'.naaa_get_html_price($precio, $market, $precio_text, $precio_old, 'card').'</span>
        </div>
		 '.$OtraTienda.'
         <span class="aawp-product__info"></span>
      </div>
  </div>
</div>';
	return $naaa_html_gridbox;					
}
function naaa_get_html_gridbox_caja_lista($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market){
	$naaa_html_gridbox = '<div class="cajaproductero productero-caja-estilo-4">
<section class="productero-single">
	<div class="imagen-productero">
            <a href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" rel="external nofollow noopener" target="_blank"><img alt="'.$titulo.'" class="amazon-img" src="'.esc_url($urlImage.'_AC_AC_SR250,250_.jpg').'" title="'.$titulo.'"></a>
        </div>
        <div class="productero-derecha">
            <p class="nombre-productero">
                <a href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" rel="external nofollow noopener" target="_blank">'.$titulo.'</a>
            </p>
            <a class="productero-comprar-boton estilo-boton-1" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" rel="nofollow noopener sponsored" style="background:; color:;" target="_blank">'.esc_html($button_text).'</a>
        </div>
</section>
</div>';
	return $naaa_html_gridbox;					
}
function naaa_get_html_gridbox_imagen_izquierda($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market){
	$naaa_html_gridbox = '<a href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" rel="external sponsored" target="_blank" title="'.$titulo.'">
        
        <img alt="'.$titulo.'" class="productero-imagen productero-imagen-grande alignleft" src="'.esc_url($urlImage.'_AC_AC_SR250,250_.jpg').'" title="'.$titulo.'">
        
    </a>';
	return $naaa_html_gridbox;					
}
function naaa_get_html_gridbox_imagen_derecha($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market){
	$naaa_html_gridbox = '<a href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" rel="external sponsored" target="_blank" title="'.$titulo.'">
        
        <img alt="'.$titulo.'" class="productero-imagen productero-imagen-grande alignright" src="'.esc_url($urlImage.'_AC_AC_SR250,250_.jpg').'" title="'.$titulo.'">
        
    </a>';
	return $naaa_html_gridbox;					
}
function naaa_get_html_gridbox_imagen_centro($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market){
	$naaa_html_gridbox = '<a href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" rel="external sponsored" target="_blank" title="'.$titulo.'">
        
        <img alt="'.$titulo.'" class="productero-imagen productero-imagen-grande rapcentroimg" src="'.esc_url($urlImage.'_AC_AC_SR500,500_.jpg').'" title="'.$titulo.'">
        
    </a>';
	return $naaa_html_gridbox;					
}
function naaa_get_html_gridbox_tienda2($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market){
	$naaa_html_gridbox = '<section class="productero-single">
	'.naaa_get_html_primeTienda2($prime).'
    <div class="amazon-imagen-correctivo">
        <a href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" rel="nofollow noopener sponsored" target="_blank"><img alt="'.$titulo.'" class="amazon-img" src="'.esc_url($urlImage.'_AC_AC_SR250,250_.jpg').'" title="'.$titulo.'"></a>
    </div>
    <p class="nombre-productero">
        <a href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" rel="nofollow noopener sponsored" target="_blank" title="'.$titulo.'">'.$titulo.'</a>
    </p>
    <div class="precios-tienda-3">
        <a class="precio-compartido" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" rel="nofollow noopener sponsored" target="_blank">'.naaa_get_html_price($precio, $market, $precio_text, $precio_old, 'card').'</a>

        <a class="comprar-boton-compartido" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" rel="nofollow noopener sponsored" style="background:#1177cc;color:#ffffff" target="_blank">Comprar</a>
    </div>
</section>';
	return $naaa_html_gridbox;					
}
function naaa_get_html_gridbox_hori($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market){
	$naaa_html_gridbox = '<tbody>
                    
            <tr class="aawp-product aawp-product--ribbon aawp-product--sale aawp-product--style-light aawp-product--bestseller" data-aawp-product-id="B074MBDM57" data-aawp-product-title="">
                                    
                                <td class="aawp-table__td-thumb" data-label="imagen">
                    <a href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="'.$titulo.'" rel="nofollow noopener sponsored" target="_blank">
					   '.naaa_get_html_descuentoTabla1($precio, $precio_old).'
                        <img class="aawp-product__img lazyloaded" src="'.esc_url($urlImage.'_AC_AC_SR250,250_.jpg').'" alt="'.$titulo.'" data-ll-status="loaded"><noscript><img class="aawp-product__img" src="'.esc_url($urlImage.'_AC_AC_SR250,250_.jpg').'" alt="'.$titulo.'"  /></noscript>
                    </a>
                </td>
                <td class="aawp-table__td-title" data-label="Producto">
                    <a class="aawp-product__title" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="'.$titulo.'" rel="nofollow noopener sponsored" target="_blank">'.$titulo.'</a>
                </td>
                                                    <td class="aawp-table__td-pricing" data-label="Precio">
                                                                                                    <span class="aawp-product__price"'.naaa_get_html_price($precio, $market, $precio_text, $precio_old, 'card').'</span><a class="'.naaa_get_html_primeHorizontal($prime).'" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="Amazon Prime" rel="nofollow noopener sponsored" target="_blank"></a></td>
                                <td class="aawp-table__td-links" data-label="Enlace">
                    <a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon aawp-button--icon aawp-button--icon-amazon-black" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="Comprar en Amazon" target="_blank" rel="nofollow noopener sponsored">'.esc_html($button_text).'</a></td>
            </tr>


                </tbody>';
	return $naaa_html_gridbox;					
}
function naaa_get_html_gridbox_tabla($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market){
	$OtraTienda= get_option('naaa_tienda_alternativa');
	if($OtraTienda == "ebay"){
	$idebay= get_option('naaa_tag_ebay');
	$texto_boton= get_option('naaa_boton_tienda_alternativa');
	$estiloboton= get_option('naaa_product_color');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
    $titulo2= trim(substr($titulo, 0, 37));
	$logoadicional='<div class="productero_amazon_amazon"> 
	    <img alt="" title="amazon" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-amazon.png">
	</div>';
	$botonadicional='';
	$OtraTienda='<div class="productero_amazon_opiniones">
       <a target="_blank">Disponible en Otra Tienda</a>
    </div>
    <div class="productero_amazon_amazon"> 
	<img alt="ebay" title="ebay" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-ebay.png">
    </div>
    <div class="productero_comprar_boton estilo_boton_'.$estiloboton.'">
	 <a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon" href="https://www.ebay.es/sch/i.html?_from=R40&_nkw='.$titulo2.'&_sacat=0&customid='.$idebay.'" title="" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important;width: 100%;border-radius: 10px 0 10px 0!important;text-transform: uppercase!important;font-weight: bold!important;border: 0!important;" target="_blank" rel="nofollow noopener sponsored">'.$texto_boton.'</a>
    </div>';
	}
	else if($OtraTienda == "aliexpress"){
	$idaliexpress= get_option('naaa_tag_aliexpress');
	$estiloboton= get_option('naaa_product_color');
	$texto_boton= get_option('naaa_boton_tienda_alternativa');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
    $titulo2= trim(substr($titulo, 0, 37));
	$logoadicional='<div class="productero_amazon_amazon"> 
	    <img alt="" title="amazon" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-amazon.png">
	</div>';
	$botonadicional='';
	$OtraTienda='<div class="productero_amazon_opiniones">
       <a target="_blank">Disponible en Otra Tienda</a>
    </div>
    <div class="productero_amazon_amazon"> 
	<img alt="aliexpress" title="aliexpress" src="https://i.postimg.cc/dV5kLKPt/logo-aliexpress.png">
    </div>
    <div class="productero_comprar_boton estilo_boton_'.$estiloboton.'">
	 <a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon" href="https://es.aliexpress.com/af/aliexpress.html?d=y&origin=n&SearchText='.$titulo2.'&?dp='.$idaliexpress.'" title="" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important;width: 100%;border-radius: 10px 0 10px 0!important;text-transform: uppercase!important;font-weight: bold!important;border: 0!important;" target="_blank" rel="nofollow noopener sponsored">'.$texto_boton.'</a>
    </div>';
	}
	else if($OtraTienda == "elCorteIngles"){
	$idawin= get_option('naaa_tag_elCorteIngles');
	$estiloboton= get_option('naaa_product_color');
	$texto_boton= get_option('naaa_boton_tienda_alternativa');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
    $titulo2= trim(substr($titulo, 0, 37));
	$logoadicional='<div class="productero_amazon_amazon"> 
	    <img alt="" title="amazon" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-amazon.png">
	</div>';
	$botonadicional='';
	$OtraTienda='<div class="productero_amazon_opiniones">
       <a target="_blank">Disponible en Otra Tienda</a>
    </div>
    <div class="productero_amazon_amazon"> 
	<img alt="elCorteIngles" title="elCorteIngles" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-elcorteingles1.png">
    </div>
    <div class="productero_comprar_boton estilo_boton_'.$estiloboton.'">
	 <a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon" href="'.$idawin.'https://www.elcorteingles.es/search/?s='.$titulo2.'&hierarchy=&deep_search=&stype=text_box" title="" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important;width: 100%;border-radius: 10px 0 10px 0!important;text-transform: uppercase!important;font-weight: bold!important;border: 0!important;" target="_blank" rel="nofollow noopener sponsored">'.$texto_boton.'</a>
    </div>';
	}
	else if($OtraTienda == "PcComponentes"){
	$idawin= get_option('naaa_tag_PcComponentes');
	$estiloboton= get_option('naaa_product_color');
	$texto_boton= get_option('naaa_boton_tienda_alternativa');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
    $titulo2= trim(substr($titulo, 0, 37));
	$logoadicional='<div class="productero_amazon_amazon"> 
	    <img alt="" title="amazon" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-amazon.png">
	</div>';
	$botonadicional='';
	$OtraTienda='<div class="productero_amazon_opiniones">
       <a target="_blank">Disponible en Otra Tienda</a>
    </div>
    <div class="productero_amazon_amazon"> 
	<img alt="PcComponentes" title="PcComponentes" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-PcComponentes.png">
    </div>
    <div class="productero_comprar_boton estilo_boton_'.$estiloboton.'">
	 <a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon" href="'.$idawin.'https://www.pccomponentes.com/buscar/?query='.$titulo2.'&page=1&or-relevance" title="" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important;width: 100%;border-radius: 10px 0 10px 0!important;text-transform: uppercase!important;font-weight: bold!important;border: 0!important;" target="_blank" rel="nofollow noopener sponsored">'.$texto_boton.'</a>
    </div>';
	}
	else if($OtraTienda == "no"){
	$estiloboton= get_option('naaa_product_color');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
		$logoadicional='';
		$OtraTienda='';
		$botonadicional='<div class="productero_comprar_boton estilo_boton_'.$estiloboton.'">
	 <a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important;width: 100%;border-radius: 10px 0 10px 0!important;text-transform: uppercase!important;font-weight: bold!important;border: 0!important;" target="_blank" rel="nofollow noopener sponsored">'.esc_html($button_text).'</a>
    </div>
	
   <div class="productero_amazon_amazon"> 
	    <img alt="" title="amazon" src="/wp-content/plugins/Amazon-Affiliates-NO-API/assets/images/logo-amazon.png">
	</div>';
	}
	$estiloboton= get_option('naaa_product_color');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
	$naaa_html_gridbox = '<div style="border: #fff0; height: ;" class="cajaproductero productos_3 estilo_tabla_1">
	<div style="color:#FFFFFF; background-color:#ffff;" class="featured_products_style_vertical">
        <span>'.naaa_get_html_descuentoTabla($precio, $precio_old).'</span>
    </div>
    
	'.naaa_get_html_primeTabla($prime).'
   <div class="aawp-tb-product-data-thumb"> 
     <a href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="" target="_blank" rel="nofollow noopener sponsored" data-aawp-product-id="" data-aawp-product-title="" data-aawp-product-=""><span class="aawp-tb-thumb"><img src="'.esc_url($urlImage.'_AC_AC_SR160,160_.jpg').'" alt="'.$titulo.'" title="'.$titulo.'"></span></a> 
   </div>

    
    '.$botonadicional.'

    <div class="nombre-productero" style="height: 68px;">
        <a href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" rel="external sponsored" target="_blank">'.$titulo.'</a>
    </div>


    <div class="productero_amazon_opiniones">
        <a href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" rel="external sponsored" target="_blank">'.naaa_get_html_price($precio, $market, $precio_text, $precio_old, 'card').'</a>
	</div>

   '.$logoadicional.'
	
   <div class="productero_comprar_boton estilo_boton_'.$estiloboton.'">
	 <a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="" style="background:'.$color_boton.'!important; color:'.$color_boton_texto.'!important; border-color: #ffffff #ffffff #ffffff!important;width: 100%;border-radius: 10px 0 10px 0!important;text-transform: uppercase!important;font-weight: bold!important;border: 0!important;" target="_blank" rel="nofollow noopener sponsored">'.esc_html($button_text).'</a>
    </div>
  '.$OtraTienda.'
</div>';
	return $naaa_html_gridbox;					
}
function naaa_get_html_gridbox_caja($asin, $button_text, $urlImage, $precio, $titulo, $precio_text, $precio_old, $valoracion, $opiniones, $prime, $market){
	$OtraTienda= get_option('naaa_tienda_alternativa');
	if($OtraTienda == "ebay"){
	$idebay= get_option('naaa_tag_ebay');
	$texto_boton= get_option('naaa_boton_tienda_alternativa');
	$estiloboton= get_option('naaa_product_color');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
	$titulo2= trim(substr($titulo, 0, 15));
	$OtraTienda='<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon aawp-button--icon aawp-button--icon-amazon-white" style="background:'.$color_boton.'!important;color:'.$color_boton_texto.'!important;border-color: #ffffff #ffffff #ffffff!important;border-radius: 15px;width: 45%;margin-left: 15px;" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="Amazon" target="_blank" rel="nofollow noopener sponsored">Comprar En Amazon</a>
	<a class="productero-comprar-boton" href="https://www.ebay.es/sch/i.html?_from=R40&_nkw='.$titulo2.'&_sacat=0&customid='.$idebay.'" rel="nofollow noopener sponsored" style="background:'.$color_boton.'!important;color:'.$color_boton_texto.'!important;border-color: #ffffff #ffffff #ffffff!important;margin-left: auto!important;border-radius: 15px;width: 45%;"  title="Ebay"  target="_blank">Comprar En Ebay</a>';
	}
	else if($OtraTienda == "aliexpress"){
	$idaliexpress= get_option('naaa_tag_aliexpress');
	$estiloboton= get_option('naaa_product_color');
	$texto_boton= get_option('naaa_boton_tienda_alternativa');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
	$titulo2= trim(substr($titulo, 0, 15));
	$OtraTienda='<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon aawp-button--icon aawp-button--icon-amazon-white" style="background:'.$color_boton.'!important;color:'.$color_boton_texto.'!important;border-color: #ffffff #ffffff #ffffff!important;border-radius: 15px;width: 45%;margin-left: 15px;" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="Amazon" target="_blank" rel="nofollow noopener sponsored">Comprar En Amazon</a>
	<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon rounded shadow aawp-button--icon aawp-button--icon-white" href="https://es.aliexpress.com/af/aliexpress.html?d=y&origin=n&SearchText='.$titulo2.'&?dp='.$idaliexpress.'" rel="nofollow noopener sponsored" style="background:'.$color_boton.'!important;color:'.$color_boton_texto.'!important;border-color: #ffffff #ffffff #ffffff!important;margin-left: auto!important;border-radius: 15px;width: 45%;"  title="Aliexpress" target="_blank">Comprar En Aliexpress</a>';
	}
	else if($OtraTienda == "elCorteIngles"){
	$idawin= get_option('naaa_tag_elCorteIngles');
	$estiloboton= get_option('naaa_product_color');
	$texto_boton= get_option('naaa_boton_tienda_alternativa');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
    $titulo2= trim(substr($titulo, 0, 37));
	$OtraTienda='<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon aawp-button--icon aawp-button--icon-amazon-white" style="background:'.$color_boton.'!important;color:'.$color_boton_texto.'!important;border-color: #ffffff #ffffff #ffffff!important;border-radius: 15px;width: 45%;margin-left: 15px;" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="Amazon" target="_blank" rel="nofollow noopener sponsored">Comprar En Amazon</a>
	<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon rounded shadow aawp-button--icon aawp-button--icon-white" href="'.$idawin.'https://www.elcorteingles.es/search/?s='.$titulo2.'&hierarchy=&deep_search=&stype=text_box" style="background:'.$color_boton.'!important;color:'.$color_boton_texto.'!important;border-color: #ffffff #ffffff #ffffff!important;margin-left: auto!important;border-radius: 15px;width: 45%;"  title="ElCorteIngles" target="_blank" rel="nofollow noopener sponsored">Comprar En ElCorteIngles</a>
    </div>';
	}
	else if($OtraTienda == "PcComponentes"){
	$idawin= get_option('naaa_tag_PcComponentes');
	$estiloboton= get_option('naaa_product_color');
	$texto_boton= get_option('naaa_boton_tienda_alternativa');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
    $titulo2= trim(substr($titulo, 0, 37));
	$OtraTienda='<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon aawp-button--icon aawp-button--icon-amazon-white" style="background:'.$color_boton.'!important;color:'.$color_boton_texto.'!important;border-color: #ffffff #ffffff #ffffff!important;border-radius: 15px;width: 45%;margin-left: 15px;" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" title="Amazon" target="_blank" rel="nofollow noopener sponsored">Comprar En Amazon</a>
	<a class="aawp-button aawp-button--buy aawp-button aawp-button--amazon rounded shadow aawp-button--icon aawp-button--icon-white" href="'.$idawin.'https://www.pccomponentes.com/buscar/?query='.$titulo2.'&page=1&or-relevance" style="background:'.$color_boton.'!important;color:'.$color_boton_texto.'!important;border-color: #ffffff #ffffff #ffffff!important;margin-left: auto!important;border-radius: 15px;width: 45%;"  title="PcComponentes" target="_blank" rel="nofollow noopener sponsored">Comprar En PcComponentes</a>
    </div>';
	}
	else if($OtraTienda == "no"){
	$estiloboton= get_option('naaa_product_color');
	$color_boton= get_option('naaa_button_bg_color');
	$color_boton_texto= get_option('naaa_button_bg_color2');
		$OtraTienda='<a class="productero-comprar-boton" href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" rel="nofollow noopener sponsored" style="background:'.$color_boton.'; color:'.$color_boton_texto.';"  target="_blank">'.esc_html($button_text).'</a>';
	}
	$color_boton= get_option('naaa_button_text_color_caja1');
	$color_boton_texto= get_option('naaa_button_text_color_caja');
	$naaa_html_gridbox = '<section class="productero-single">
        <center>
        <div class="descuento-productero">
                <a rel="external nofollow noopener" target="_blank">'.naaa_get_html_descuentocaja($precio, $precio_old).'</a>
        </div>
		   '.naaa_get_html_primeTienda2($prime).'
            <div class="amazon-imagen-correctivo">
                <a href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" rel="nofollow noopener sponsored" target="_blank"><img alt="'.$titulo.'" class="amazon-img" src="'.esc_url($urlImage.'_AC_AC_SR250,250_.jpg').'" title="'.$titulo.'"></a>
            </div>
        </center>
        <p class="nombre-productero">
       <a href="'.esc_url(naaa_get_amazon_url_product($asin, $market)).'" rel="nofollow noopener sponsored" target="_blank">'.$titulo.'</a></p>
	  '.$OtraTienda.'
        <div class="descuento-productero-texto">
            <a rel="nofollow noopener sponsored" target="_blank">'.naaa_get_html_descuentocaja2($precio, $precio_old).'</a>
        </div>
    </section>';
	return $naaa_html_gridbox;					
}


function naaa_get_html_grid($asin, $button_text, $precio_text, $market, $template, $heading, $bestseller, $max) {
	$columna=get_option('naaa_num_items_row',3);
	if (naaa_is_valid_market($market)){
		$market = strtolower($market);
	}else{
		$market = strtolower(get_option('naaa_amazon_country','es'));
	}

	if(!empty($bestseller)){
		$asin = naaa_get_asin_list_bestseller($bestseller, $market);
	}
	$asinList = explode(",", $asin);
	
	$button_text = trim($button_text);
	if($button_text == ''){
		$button_text = __('Ver más', 'no-api-amazon-affiliate');
	}
	$precio_text = trim($precio_text);

	$max = naaa_get_numeric($max);

if($template == 'tabla'){
	$naaa_container = '<div class="tabla_productero">
    <div class="tabla_productero_sin_sombra">';
}else if($template == 'caja'){
    $naaa_container = '<div class="cajaproductero productero-caja-estilo-1">';
}else if($template == 'tienda2'){
    $naaa_container = '<div class="tiendaproductero productero-6-grid productero-tienda-estilo-3">';
}else if($template == 'card'){
    $naaa_container = '<div class="aawp">
   <div class="aawp-grid aawp-grid--col-'.$columna.'">';
}else if($template == 'caja_lista'){
    $naaa_container = '';
}else if($template == 'caja_amazon'){
    $naaa_container = '<div class="aawp">';
}else if($template == 'widget_vertical'){
    $naaa_container = '';
}else if($template == 'horizontal'){
    $naaa_container = '<div class="aawp">

    <table class="aawp-table">
        <thead>
            <tr>
                                    
                                <th class="aawp-table__th-thumb">Vista previa</th>
                <th class="aawp-table__th-title">Producto</th>
                                                    <th class="aawp-table__th-pricing">Precio</th>
                                <th class="aawp-table__th-links"></th>
            </tr>
        </thead>';
}else if($template == 'imagen_izquierda'){
    $naaa_container = '';
}else if($template == 'boton'){
    $naaa_container = '';
}else if($template == 'imagen_derecha'){
    $naaa_container = '';
}else if($template == 'imagen_centro'){
    $naaa_container = '';
}else{
	$naaa_container = '<div class="container">
							<div class="naaa-grid">';
	}
	foreach ($asinList as $asinUnit) {
		if($max <= 0) break;
		$asinUnitArray = explode("-", trim($asinUnit));
		$finalAsinUnit = $asinUnitArray[0];
		if (count($asinUnitArray)>1) {
			$finalMarket = $asinUnitArray[1];
		}else{
			$finalMarket = $market;
		}
		$finalMarket = strtolower($finalMarket);
		$item_data = naaa_get_item_data($finalAsinUnit, $finalMarket);
		//Definimos el título a usar
		if(empty($item_data['titulo_manual'])){
			$title = $item_data['titulo'];
		}else{
			$title = $item_data['titulo_manual'];
		}


		if (!empty($item_data)){
			$naaa_container .=  naaa_get_html_gridbox($finalAsinUnit,
														$button_text,
														$item_data['imagen_url'],
														$item_data['precio'],
														$title,
														$precio_text,
														$item_data['precio_anterior'],
														$item_data['valoracion'],
														$item_data['opiniones'],
														$item_data['prime'],
														$finalMarket,
														$template,
														$heading);
			$max--;
		}
	}
	
if($template == 'tabla'){
	$naaa_container .=  	'</div>
						</div>';
}else if($template == 'caja'){
	$naaa_container .= '</div>';
}else if($template == 'tienda2'){
	$naaa_container .= '</div>';
}else if($template == 'imagen_centro'){
	$naaa_container .= '</a>';
}else if($template == 'imagen_derecha'){
	$naaa_container .= '</a>';
}else if($template == 'imagen_izquierda'){
	$naaa_container .= '</a>';
}else if($template == 'boton'){
	$naaa_container .= '</a>';
}else if($template == 'caja_lista'){
	$naaa_container .= '';
}else if($template == 'caja_amazon'){
	$naaa_container .= '</div>';
}else if($template == 'widget_vertical'){
	$naaa_container .= '';
}else if($template == 'card'){
	$naaa_container .= '</div>
                 </div>';
}else if($template == 'horizontal'){
	$naaa_container .= '</table>
                    </div>';
}else{
	$naaa_container .=  	'</div>
						</div>';
}	  
	return $naaa_container;
}

function naaa_get_html_title_list($title, $title_manual){
	$title_html = '';
	if(empty($title_manual)){
		$title_html = $title;
	}else{
		$title_html = '<del>'.$title.'</del><br>'.$title_manual;
	}
	return $title_html;
}

?>